do not cheat
this code is just for fun
Not responsible for the consequences

